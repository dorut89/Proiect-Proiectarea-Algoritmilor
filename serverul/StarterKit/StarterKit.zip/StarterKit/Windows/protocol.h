#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#define P_TEAMNAME      1
#define P_MAP_DIM       2
#define P_INITIAL_INFO  3
#define P_CAR_CONFIG    4
#define P_CAR_CONFIRM   4
#define P_DRIVE_INFO    5
#define P_POS_CONFIRM   6
#define P_ENDRACE       7

#endif
