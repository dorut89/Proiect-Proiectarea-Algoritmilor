/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hotpursuit;

/**
 *
 * @author Andrei
 */
public class Command {
    double acc;
    double dec;
    double str;

    @Override
    public String toString() {
        return "(acc = "+ this.acc + ", dec = " + this.dec + ", str = " + this.str + ")";
    }
}

