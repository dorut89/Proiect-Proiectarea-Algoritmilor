/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hotpursuit;

/**
 *
 * @author Andrei
 */
public class Limits {
    public int acc;
    public int brk;
    public int spd;
    public double str;

    @Override
    public String toString() {
        return "(acc = "+ this.acc + ", dec = " + this.brk + ", spd = " + this.spd + ", str = " + this.str + ")";
    }
}

